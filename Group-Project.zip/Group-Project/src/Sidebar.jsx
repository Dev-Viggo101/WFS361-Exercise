function Sidebar(){
    return(
        <>

            <div id='sidebar'></div>
        
        </>
    );
}

export default Sidebar