import Card from './card.jsx'
import Footer from './footer.jsx'
import Header from './header.jsx'
import Menu from './menu-exercise.jsx'
import Sidebar from './sidebar.jsx'
import './App.css'

function App() {
  return (
    <div id='app'>
      
      <Header></Header>
      <Sidebar></Sidebar>
      <Card></Card>
      <Footer></Footer>
        

    </div>
  )
}

export default App
