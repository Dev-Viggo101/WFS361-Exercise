function Card(){
    return(
        <>
        
            <div className="psss" id='card'>

                <p></p>
                <p></p>
                <p></p>
                <p></p>

            </div>
        
        </>
    );
}

export default Card