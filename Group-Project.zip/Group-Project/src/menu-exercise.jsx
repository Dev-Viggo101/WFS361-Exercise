import './menu-exercise.css'

function Menu(){
    return(
        <div>
            
            <nav>

                <ul>

                    <div id='home'>
                        <a href='#'><li className='links'>Home</li></a>
                    </div>
                    
                    <div id='navBar'>

                        <a href='#'><li className='links'>Products</li></a>
                        <a href='#'><li className='links'>Services</li></a>
                        <a href='#'><li className='links'>Team</li></a>
                        <a href='#'><li className='links'>Portfolio</li></a>
                        <a href='#'><li className='links'>Blog</li></a>
                        <a href='#'><li className='links'>Contact</li></a>

                    </div>

                    <div id='myBlog'>
                        <a href='#'><li className='links' id='blog'>Go my Blog</li></a>
                    </div>

                </ul>

            </nav>

        </div>
    );
}

export default Menu